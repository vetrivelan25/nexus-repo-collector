package com.capitalone.dashboard.collector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Component;

import com.capitalone.dashboard.model.Artifact;
import com.capitalone.dashboard.model.Build;
import com.capitalone.dashboard.model.NexusCollector;
import com.capitalone.dashboard.model.NexusRepo;
import com.capitalone.dashboard.repository.ArtifactRepository;
import com.capitalone.dashboard.repository.BaseCollectorRepository;
import com.capitalone.dashboard.repository.ComponentRepository;
import com.capitalone.dashboard.repository.NexusCollectorRepository;
import com.capitalone.dashboard.repository.NexusRepository;

/**
 * CollectorTask that fetches Build information from Hudson
 */
@Component
public class NexusCollectorTask extends CollectorTask<NexusCollector> {

	private static final Log LOG = LogFactory.getLog(NexusCollectorTask.class);

	private final NexusCollectorRepository nexusCollectorRepository;
	private final NexusRepository nexusJobRepository;
	private final ArtifactRepository artifactRepository;
	private final NexusClient nexusClient;
	private final NexusSettings nexusSettings;
	private final ComponentRepository dbComponentRepository;
	private final int CLEANUP_INTERVAL = 3600000;

	@Autowired
	public NexusCollectorTask(TaskScheduler taskScheduler,
			NexusCollectorRepository nexusCollectorRepository,
			NexusRepository nexusJobRepository,
			ArtifactRepository artifactRepository, NexusClient nexusClient,
			NexusSettings nexusSettings,
			ComponentRepository dbComponentRepository) {
		super(taskScheduler, "Nexus");
		this.nexusCollectorRepository = nexusCollectorRepository;
		this.nexusJobRepository = nexusJobRepository;
		this.artifactRepository = artifactRepository;
		this.nexusClient = nexusClient;
		this.nexusSettings = nexusSettings;
		this.dbComponentRepository = dbComponentRepository;
	}

	@Override
	public NexusCollector getCollector() {
		return NexusCollector.prototype(nexusSettings.getRepos());
	}

	@Override
	public BaseCollectorRepository<NexusCollector> getCollectorRepository() {
		return nexusCollectorRepository;
	}

	@Override
	public String getCron() {
		return nexusSettings.getCron();
	}

	@Override
	public void collect(NexusCollector collector) {
		long start = System.currentTimeMillis();
		log("Fetched repos", start);
		for (String instanceUrl : collector.getArtifactRepos()) {
			logInstanceBanner(instanceUrl);
			
			for (NexusRepo repo : enabledRepos(collector , instanceUrl)) {
				addRepo(repo, collector);
				

				addNewArtifacts(instanceUrl , repo);

				
			}
			log("Finished", start);

		}

	}


	/**
	 * Iterates over the enabled build jobs and adds new builds to the database.
	 *
	 * @param enabledJobs
	 *            list of enabled {@link NexusRepo}s
	 * @param buildsByJob
	 *            maps a {@link NexusRepo} to a set of {@link Build}s.
	 */
	private void addNewArtifacts(String Url ,NexusRepo repo )  {
		long start = System.currentTimeMillis();
		int count = 0;
		List<Artifact> artifactsNew	=	new ArrayList<>();
		List<Artifact> artifacts = nexusClient.getArtifactDetails(Url , repo);
		for(Artifact artifact : artifacts){
			if (artifact != null) {
				artifact.setCollectorItemId(repo.getId());
				
				if (isNewArtifact(artifact)){
					artifactsNew.add(artifact);
				}
				
				count++;
			}
		}
		artifactRepository.save(artifactsNew);	
		
		log("New builds", start, count);
	}

	
	/**
	 * Adds new {@link NexusRepo}s to the database as disabled jobs.
	 *
	 * @param repos
	 *            list of {@link NexusRepo}s
	 * @param collector
	 *            the {@link NexusCollector}
	 */
	private void addRepo(NexusRepo repo, NexusCollector collector) {

		System.out.println("URL : "+repo.getUrl());
		System.out.println("Group ID : "+repo.getGroupId());
		if (isNewRepo(collector, repo)) {
				repo.setCollectorId(collector.getId());
				repo.setEnabled(false); // Do not enable for collection. Will be
										// enabled when added to dashboard
				repo.setDescription(repo.getGroupId());
				System.out.println("New Collector item created");
				nexusJobRepository.save(repo);
				
		}
		
	}

	private List<NexusRepo> enabledRepos(NexusCollector collector,
			String instanceUrl) {
		return nexusJobRepository.findEnabledNexusRepos(collector.getId());
	}

	private boolean isNewRepo(NexusCollector collector, NexusRepo repo) {
		return nexusJobRepository.findNexusRepo(collector.getId(),
				repo.getUrl(), repo.getGroupId()) == null;
	}

	 private boolean isNewArtifact(Artifact artifact ) {
	    	return artifactRepository.findByCollectorItemIdAndArtifactsIdAndVersion(
	    			artifact.getCollectorItemId() , artifact.getArtifactsId() , artifact.getVersion()) == null;
		}

//	private void log(String marker, long start) {
//		log(marker, start, null);
//	}
//
//	private void log(String text, long start, Integer count) {
//		long end = System.currentTimeMillis();
//		String elapsed = ((end - start) / 1000) + "s";
//		String token2 = "";
//		String token3;
//		if (count == null) {
//			token3 = StringUtils.leftPad(elapsed, 30 - text.length());
//		} else {
//			String countStr = count.toString();
//			token2 = StringUtils.leftPad(countStr, 20 - text.length());
//			token3 = StringUtils.leftPad(elapsed, 10);
//		}
//		LOG.info(text + token2 + token3);
//	}

	private void logInstanceBanner(String instanceUrl) {
		LOG.info("------------------------------");
		LOG.info(instanceUrl);
		LOG.info("------------------------------");
	}
}
