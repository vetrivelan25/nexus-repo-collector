package com.capitalone.dashboard.collector;

import java.io.StringReader;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestOperations;

import com.capitalone.dashboard.model.Artifact;
import com.capitalone.dashboard.model.Build;
import com.capitalone.dashboard.model.BuildStatus;
import com.capitalone.dashboard.model.NexusRepo;
import com.capitalone.dashboard.model.SCM;
import com.capitalone.dashboard.util.Supplier;

/**
 * HudsonClient implementation that uses RestTemplate and JSONSimple to
 * fetch information from Hudson instances.
 */
@Component
public class DefaultNexusClient implements NexusClient {
    private static final Log LOG = LogFactory.getLog(DefaultNexusClient.class);

    private final RestOperations rest;
    private final NexusSettings settings;

    private static final String REPO_ARTIFACTS_SUFFIX = "/service/local/lucene/search?g=";

   
    @Autowired
    public DefaultNexusClient(Supplier<RestOperations> restOperationsSupplier, NexusSettings settings) {
        this.rest = restOperationsSupplier.get();
        this.settings = settings;
    }



    @Override
    public List<Artifact> getArtifactDetails(String repoUrl , NexusRepo repo ) {
        try {
            String url = StringUtils.removeEnd(repoUrl, "/") + REPO_ARTIFACTS_SUFFIX;
            url=url+repo.getGroupId();
            ResponseEntity<String> result = makeRestCall(URI.create(url));
            System.out.println("URL = "+url);
            String returnXML = result.getBody();
            List<Artifact> artifacts	=	new ArrayList<>();
            Collection<Artifact> artifacthistory	=	new ArrayList<>();
            Artifact	artifact	=	null;
            	
            SAXReader reader = new SAXReader();
            Document document = reader.read(new StringReader(returnXML));
            List list = document.selectNodes( "//data/artifact" );
            System.out.println("Artifact count = "+list.size());
            for (Iterator iter = list.iterator(); iter.hasNext(); ) {
            	Node artifactNode = (Node)iter.next();
                Node artifactID	=	(Node)artifactNode.selectSingleNode("artifactId");
                Node version	=	(Node)artifactNode.selectSingleNode("version");
                Node latestRelease	=	(Node)artifactNode.selectSingleNode("latestRelease");
                Node extension	=	(Node)artifactNode.selectSingleNode("artifactHits/artifactHit/artifactLinks/artifactLink[2]/extension");
                Node repositoryId	=	(Node)artifactNode.selectSingleNode("latestReleaseRepositoryId");
                
                if (extension != null){
                	 System.out.println("Artifact ID = "+artifactID.getStringValue());
                     System.out.println("version = "+version.getStringValue());
                     System.out.println("latestRelease = "+latestRelease.getStringValue());
                     System.out.println("extension = "+extension.getStringValue());
                   
                     
                     if (version.getStringValue().equals(latestRelease.getStringValue()) ){
                     	
                     	artifact	=	new Artifact();
                     	artifacthistory	=	new ArrayList<>();
                     	artifact.setArtifactsId(artifactID.getStringValue());
                     	artifact.setVersion(version.getStringValue());
                     	artifact.setExtension(extension.getStringValue());
                     	artifact.setRepositoryId(repositoryId.getStringValue());
                     	artifacthistory	=	new ArrayList<>();
                     	artifact.setArtifactHistory(artifacthistory);
                     	artifacts.add(artifact);
                     } else {
                    	artifact	=	new Artifact();
                      	artifact.setArtifactsId(artifactID.getStringValue());
                      	artifact.setVersion(version.getStringValue());
                      	artifact.setExtension(extension.getStringValue());
                      	artifact.setRepositoryId(repositoryId.getStringValue());
                      	artifacthistory.add(artifact);
                     }
                }
               
                
            }
            System.out.println("Artifacts Size : "+ artifacts);
              return artifacts;
 
        } catch (RestClientException rce) {
            LOG.error(rce);
        } catch (DocumentException de) {
        	LOG.error(de);
		}

        return null;
    }


   



	private ResponseEntity<String> makeRestCall(URI uri) {
        // Basic Auth only.
        if (StringUtils.isNotEmpty(this.settings.getUsername())
                && StringUtils.isNotEmpty(this.settings.getApiKey())) {
            return rest.exchange(uri, HttpMethod.GET,
                    new HttpEntity<>(createHeaders(this.settings.getUsername(), this.settings.getApiKey())),
                    String.class);

        } else {
            return rest.exchange(uri, HttpMethod.GET, null,
                    String.class);
        }

    }

    private HttpHeaders createHeaders(final String userId, final String password) {
        return new HttpHeaders() {
            {
                String auth = userId + ":" + password;
                byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
                String authHeader = "Basic " + new String(encodedAuth);
                set(HttpHeaders.AUTHORIZATION, authHeader);
            }
        };
    }


}
