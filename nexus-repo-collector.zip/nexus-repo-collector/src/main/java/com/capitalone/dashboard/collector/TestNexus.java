package com.capitalone.dashboard.collector;

import java.util.ArrayList;
import java.util.List;

public class TestNexus {

//	public static void main(String[] args) {
//		RestOperationsSupplier restOperationsSupplier	=	new RestOperationsSupplier();
//		NexusSettings	settings = new NexusSettings();
//		List	list	=	new ArrayList<>();
//		list.add("http://localhost:8081/nexus");
//		settings.setRepos(list);
//		settings.setGroupId("Hygieia");
//		
//		DefaultNexusClient	client	=	new DefaultNexusClient(restOperationsSupplier, settings);
//		client.getArtifactDetails("http://localhost:8081/nexus");
//		
//
//	}

}
