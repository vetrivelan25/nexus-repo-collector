package com.capitalone.dashboard.repository;

import com.capitalone.dashboard.model.NexusRepo;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;


public interface NexusRepository extends BaseCollectorItemRepository<NexusRepo> {

    @Query(value="{ 'collectorId' : ?0, options.url : ?1, options.groupid : ?2}")
    NexusRepo findNexusRepo(ObjectId collectorId, String instanceUrl, String groupid);

    @Query(value="{ 'collectorId' : ?0, enabled: true}")
    List<NexusRepo> findEnabledNexusRepos(ObjectId collectorId);
}
