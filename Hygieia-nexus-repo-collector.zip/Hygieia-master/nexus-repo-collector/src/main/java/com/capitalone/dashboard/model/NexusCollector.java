package com.capitalone.dashboard.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Extension of Collector that stores current build server configuration.
 */
public class NexusCollector extends Collector {
    private List<String> artifactRepos = new ArrayList<>();

    public List<String> getArtifactRepos() {
        return artifactRepos;
    }

    public void setArtifactRepos(List<String> artifactRepos) {
        this.artifactRepos = artifactRepos;
    }

    public static NexusCollector prototype(List<String> artifactRepos) {
    	NexusCollector protoType = new NexusCollector();
        protoType.setName("Nexus");
        protoType.setCollectorType(CollectorType.Artifact);
        protoType.setOnline(true);
        protoType.setEnabled(true);
        protoType.getArtifactRepos().addAll(artifactRepos);
        return protoType;
    }
}
