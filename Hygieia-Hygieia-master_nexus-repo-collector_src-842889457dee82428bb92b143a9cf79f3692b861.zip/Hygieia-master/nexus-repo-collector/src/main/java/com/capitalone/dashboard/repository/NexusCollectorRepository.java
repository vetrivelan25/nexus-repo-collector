package com.capitalone.dashboard.repository;

import com.capitalone.dashboard.model.NexusCollector;

/**
 * Collector repository for the HudsonCollector subclass
 */
public interface NexusCollectorRepository extends BaseCollectorRepository<NexusCollector> {
}
