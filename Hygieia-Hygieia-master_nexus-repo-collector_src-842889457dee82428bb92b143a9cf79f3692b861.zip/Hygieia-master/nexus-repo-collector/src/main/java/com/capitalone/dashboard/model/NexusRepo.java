package com.capitalone.dashboard.model;

/**
 * CollectorItem extension to store the instance, build job and build url.
 */
public class NexusRepo extends CollectorItem {
    private static final String URL = "url";
    private static final String GROUPID = "groupid";

    public String getUrl() {
        return (String) getOptions().get(URL);
    }

    public void setUrl(String instanceUrl) {
        getOptions().put(URL, instanceUrl);
    }

    public String getGroupId() {
        Object groupid = getOptions().get(GROUPID);
        return (String)groupid;
    }

    public void setGroupId(String groupid) {
        getOptions().put(GROUPID, groupid);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
        	return true;
        }
        if (o == null || getClass() != o.getClass()) {
        	return false;
        }

        NexusRepo nexusRepo = (NexusRepo) o;

        return getUrl().equals(nexusRepo.getUrl());
    }

    @Override
    public int hashCode() {
        return getUrl().hashCode();
    }
}
